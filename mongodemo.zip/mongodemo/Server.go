package main

import (
	"github.com/gorilla/mux"
	"log"
	"mongodemo/controllers"
	"net/http"
)

func main(){
	 //Config.ConnectDB()
	router:= mux.NewRouter()

	router.HandleFunc("/player",controllers.GetPlayers).Methods("GET")
	router.HandleFunc("/player/{id}",controllers.GetPlayerById).Methods("GET")
	router.HandleFunc("/player",controllers.CreatePlayer).Methods("POST")
	router.HandleFunc("/player/club/{club}",controllers.GetPlayerByClub).Methods("GET")
    router.HandleFunc("/player/{id}",controllers.DeletePlayerById).Methods("DELETE")
	router.HandleFunc("/player/{id}",controllers.UpdatePlayerById).Methods("PUT")
	log.Fatal(http.ListenAndServe(":4000",router))

}
