package models

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Player struct {
	Id primitive.ObjectID `json:"_id" bson:"_id,omitempty"`
	Name string `json:"name"`
	Position string `json:"position"`
	Club  string `json:"club"`
	Rating int `json:"rating"`
}
