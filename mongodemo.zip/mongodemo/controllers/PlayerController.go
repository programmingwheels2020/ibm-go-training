package controllers

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/gorilla/mux"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"log"
	"mongodemo/Config"
	"mongodemo/models"
	"net/http"
)

func GetPlayers(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type","application/json")
	collection:= Config.ConnectDB()
    var players []models.Player
    cur, err := collection.Find(context.TODO(),bson.M{})
    if err!=nil{
    	log.Fatal(err)
	}
	for cur.Next(context.TODO()){
		var player models.Player
		err:= cur.Decode(&player)
		if err!=nil{
			log.Fatal(err)
		}
		players = append(players,player);
	}
	//Config.DisconnectDB()
	json.NewEncoder(w).Encode(players)
}


func GetPlayerById(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type","application/json")
	collection:= Config.ConnectDB()
	var player models.Player
	var params = mux.Vars(r)
    id,_:= primitive.ObjectIDFromHex(params["id"])
	err := collection.FindOne(context.TODO(),bson.M{"_id":id}).Decode(&player)
	if err!=nil{
		log.Fatal(err)
	}

	//Config.DisconnectDB()
	json.NewEncoder(w).Encode(player)
}


func GetPlayerByClub(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type","application/json")
	collection:= Config.ConnectDB()
	var players []models.Player
	var params = mux.Vars(r)
	fmt.Println(params);
	cur, err := collection.Find(context.TODO(),bson.M{"club":params["club"]})
	if err!=nil{
		log.Fatal(err)
	}
	for cur.Next(context.TODO()){
		var player models.Player
		err:= cur.Decode(&player)
		if err!=nil{
			log.Fatal(err)
		}
		players = append(players,player);
	}
	//Config.DisconnectDB()
	json.NewEncoder(w).Encode(players)
}

func CreatePlayer(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type","application/json")
	collection:= Config.ConnectDB()
	 var player models.Player
     json.NewDecoder(r.Body).Decode(&player)
	 result,err:= collection.InsertOne(context.TODO(),player)
	 if err!=nil{
	 	log.Fatal(err)
	 }

	 json.NewEncoder(w).Encode(result)

	//json.NewEncoder(w).Encode(nil)
}

func DeletePlayerById(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type","application/json")
	collection:= Config.ConnectDB()
	var params = mux.Vars(r)
	id,_:= primitive.ObjectIDFromHex(params["id"])
	result,err := collection.DeleteOne(context.TODO(),bson.M{"_id":id})
	if err!=nil{
		log.Fatal(err)
	}

	//Config.DisconnectDB()
	json.NewEncoder(w).Encode(result)
}

func UpdatePlayerById(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type","application/json")
	collection:= Config.ConnectDB()
	var params = mux.Vars(r)
	var player models.Player
	json.NewDecoder(r.Body).Decode(&player)
	id,_:= primitive.ObjectIDFromHex(params["id"])
	update:= bson.D{
		{
			"$set",bson.D{
				{"name",player.Name},
			{"position",player.Position},
			{"rating",player.Rating},
			{"club",player.Club},
		},
		},
	}
	result,err := collection.UpdateOne(context.TODO(),bson.M{"_id":id},update)
	if err!=nil{
		log.Fatal(err)
	}

	//Config.DisconnectDB()
	json.NewEncoder(w).Encode(result)
}