package Config

import (
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"log"
)

const uri = "mongodb://localhost:27017/?maxPoolSize=20&w=majority"

var client *mongo.Client;

func ConnectDB() *mongo.Collection {

	 client, err:= mongo.Connect(context.TODO(),options.Client().ApplyURI(uri))
     if err!=nil{
	 	log.Fatal(err)
	 }else{
		 fmt.Println("Connection to the database has been established")
	 }


	 collection:= client.Database("footballdb").Collection("players")

	 return collection

}

func DisconnectDB(){
	if err := client.Disconnect(context.TODO()); err != nil {
		panic(err)
	}
}
